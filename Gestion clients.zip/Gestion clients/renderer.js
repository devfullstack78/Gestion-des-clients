const { ipcRenderer } = require('electron');

// Gestionnaire de formulaire révisé
class FormHandler {
  constructor() {
    this.form = document.getElementById('form');
    this.isSubmitting = false;
    this.setupEvents();
  }

  setupEvents() {
    this.form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (this.isSubmitting) return;
      
      this.isSubmitting = true;
      this.disableForm();

      try {
        const data = this.getFormData();
        const response = await this.submitForm(data);
        this.handleResponse(response);
      } catch (error) {
        console.error('Erreur:', error);
        alert("❌ Une erreur est survenue");
      } finally {
        this.isSubmitting = false;
        this.enableForm();
      }
    });
  }

  getFormData() {
    return {
      nom: this.form.nom.value,
      telephone: this.form.telephone.value,
      mail: this.form.mail.value,
      objet: this.form.objet.value
    };
  }

  submitForm(data) {
    return new Promise((resolve) => {
      ipcRenderer.send('ajouter-client', data);
      ipcRenderer.once('ajout-reponse', (event, response) => resolve(response));
    });
  }

  handleResponse(response) {
    if (response.success) {
      alert(`✅ Client ajouté avec l'ID : ${response.id}`);
      this.form.reset();
    } else {
      alert(`❌ Erreur : ${response.error}`);
    }
  }

  disableForm() {
    const inputs = this.form.querySelectorAll('input, button');
    inputs.forEach(el => el.disabled = true);
  }

  enableForm() {
    const inputs = this.form.querySelectorAll('input, button');
    inputs.forEach(el => el.disabled = false);
  }
}

// Initialisation
new FormHandler();

// [Conserver le reste du code existant pour la recherche]

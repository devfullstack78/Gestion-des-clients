const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'base_client'
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Erreur de connexion MySQL :', err);
    return;
  }
  console.log('✅ Connexion à MySQL réussie !');

  // Insertion test
  const sql = 'INSERT INTO clients (nom, telephone, mail, objet) VALUES (?, ?, ?, ?)';
  const valeurs = ['Rayane Doudou', '0123456789', 'rayane@example.com', 'Test depuis Node.js'];

  connection.query(sql, valeurs, (err, result) => {
    if (err) {
      console.error('❌ Erreur lors de l’insertion :', err.message);
    } else {
      console.log('✅ Données insérées avec succès ! ID :', result.insertId);
    }
    connection.end();
  });
});

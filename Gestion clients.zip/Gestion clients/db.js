const mysql = require('mysql2');

// Créer la connexion à la base de données
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'base_client',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 10000 // 10 secondes timeout
});

// Gestion des erreurs de pool
pool.on('error', (err) => {
  console.error('Erreur de pool MySQL:', err);
});

module.exports = pool;

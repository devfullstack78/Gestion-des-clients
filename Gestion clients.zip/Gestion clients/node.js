const { ipcRenderer } = require('electron');

document.getElementById('client-form').addEventListener('submit', (e) => {
  e.preventDefault();

  const nom = document.getElementById('nom').value;
  const telephone = document.getElementById('telephone').value;
  const mail = document.getElementById('mail').value;
  const objet = document.getElementById('objet').value;

  // Envoie les données à main.js pour les insérer dans la base de données
  ipcRenderer.send('ajouter-client', { nom, telephone, mail, objet });
});

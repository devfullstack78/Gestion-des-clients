-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 27 avr. 2025 à 14:51
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `base_client`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `objet` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `telephone`, `mail`, `objet`) VALUES
(1, 'doudou', '0668626887', 'rayane78450@gmail.com', 'Iphone Xs'),
(2, 'belmou', '0646832437', 'mehdi@bel.com', 'Iphone 16'),
(3, 'marotte', '0654525856', 'marotte@gmail.com', 'Reparation ecran PC'),
(4, 'mouny', '066545852', 'mouny@haryth.fr', 'iPhone 7'),
(5, 'dagnet', '0654585254', 'dagnet@bascan.com', 'Samsung S20'),
(6, 'anass', '0657841422', 'anass@anass.fr', 'Iphone 5'),
(7, 'mili', '0677335522', 'mili@fedi.frf', 'Ecouteurs'),
(8, 'hamila', '0625324777', 'hamila@iram.fr', 'Coque'),
(9, 'bono', '0622775599', 'r1@bono.fr', 'Souris');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'base_client'
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Erreur de connexion :', err);
    return;
  }

  console.log('✅ Connexion réussie');

  // Vérifier l'existence de la table clients
  connection.query("SHOW TABLES LIKE 'clients'", (err, results) => {
    if (err) {
      console.error('❌ Erreur vérification table :', err);
      return;
    }

    if (results.length === 0) {
      console.log('⚠️ Table "clients" non trouvée');
      // Créer la table si elle n'existe pas
      const createTableSQL = `CREATE TABLE clients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(255) NOT NULL,
        telephone VARCHAR(20) NOT NULL,
        mail VARCHAR(255) NOT NULL,
        objet TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`;
      
      connection.query(createTableSQL, (err) => {
        if (err) {
          console.error('❌ Erreur création table :', err);
        } else {
          console.log('✅ Table "clients" créée avec succès');
        }
        connection.end();
      });
    } else {
      console.log('✅ Table "clients" existe');
      connection.end();
    }
  });
});

const db = require('./db.js');

db.query('SHOW TABLES LIKE "clients"', (err, results) => {
  if (err) {
    console.error('Erreur:', err);
    return;
  }
  
  if (results.length === 0) {
    console.log('La table "clients" n\'existe pas');
  } else {
    console.log('La table "clients" existe');
    // Vérifier la structure de la table
    db.query('DESCRIBE clients', (err, structure) => {
      if (err) {
        console.error('Erreur:', err);
        return;
      }
      console.log('Structure de la table:');
      console.log(structure);
    });
  }
  
  db.end();
});

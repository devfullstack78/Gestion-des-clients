const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const pool = require('./db');

// Vérification de la connexion au démarrage
pool.getConnection((err, connection) => {
  if (err) {
    console.error('❌ Erreur connexion DB:', err);
    process.exit(1);
  }
  console.log('✅ Connecté à MySQL avec ID:', connection.threadId);
  connection.release();
});

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false // Permet l’IPC entre main.js et renderer.js
    }
  });

  win.loadFile('index.html');
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Gestion de l'insertion des clients
ipcMain.on('ajouter-client', (event, data) => {
  console.log('📩 Données reçues depuis renderer.js :', data);

  const sql = 'INSERT INTO clients (nom, telephone, mail, objet) VALUES (?, ?, ?, ?)';
  pool.query(sql, [data.nom, data.telephone, data.mail, data.objet], (err, result) => {
    if (err) {
      console.error('❌ Erreur insertion :', err.sqlMessage);
      event.reply('ajout-reponse', { 
        success: false, 
        error: err.sqlMessage
      });
    } else {
      console.log('✅ Client ajouté ! ID :', result.insertId);
      event.reply('ajout-reponse', { success: true, id: result.insertId });
    }
  });
});

// Gestion de la recherche des clients
ipcMain.on('rechercher-client', (event, searchTerm) => {
  console.log('🔍 Recherche client avec :', searchTerm);
  const sql = 'SELECT * FROM clients WHERE nom LIKE ? OR telephone LIKE ?';
  const searchQuery = `%${searchTerm}%`;

  pool.query(sql, [searchQuery, searchQuery], (err, results) => {
    if (err) {
      console.error('❌ Erreur recherche :', err);
      event.reply('resultat-recherche', []);
    } else {
      console.log('✅ Résultats trouvés :', results.length);
      event.reply('resultat-recherche', results);
    }
  });
});

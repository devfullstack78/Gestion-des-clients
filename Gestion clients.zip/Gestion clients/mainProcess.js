const { ipcMain } = require('electron');
const connection = require('./db');

// Écoute de l'événement 'ajouter-client' pour insérer un client
ipcMain.on('ajouter-client', (event, clientData) => {
  const { nom, telephone, mail, objet } = clientData;

  const query = 'INSERT INTO clients (nom, telephone, mail, objet) VALUES (?, ?, ?, ?)';
  connection.query(query, [nom, telephone, mail, objet], (err, results) => {
    if (err) {
      console.error('Erreur lors de l\'ajout du client :', err);
      return;
    }
    console.log('Client ajouté avec succès:', results);
  });
});

// Écoute de l'événement 'rechercher-client' pour chercher des clients
ipcMain.on('rechercher-client', (event, searchTerm) => {
  const query = 'SELECT * FROM clients WHERE nom LIKE ? OR telephone LIKE ? OR mail LIKE ? OR objet LIKE ?';
  const searchPattern = `%${searchTerm}%`;
  
  connection.query(query, 
    [searchPattern, searchPattern, searchPattern, searchPattern], 
    (err, results) => {
      if (err) {
        console.error('Erreur lors de la recherche:', err);
        return;
      }
      event.sender.send('resultat-recherche', results);
    }
  );
});

const db = require('./db');

// Test de connexion simple
db.query('SELECT 1', (err) => {
  if (err) {
    console.error('❌ Erreur de connexion:', err);
    process.exit(1);
  }
  console.log('✅ Connexion MySQL fonctionnelle');
  db.end();
});
